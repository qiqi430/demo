set names utf8;
DROP DATABASE IF EXISTS Blog;
CREATE DATABASE Blog CHARACTER SET utf8 COLLATE utf8_general_ci ;
use Blog;
CREATE TABLE `user` (
 user_id   INT AUTO_INCREMENT PRIMARY KEY,
`username` char(40) DEFAULT NULL,
`usersex` char(40) DEFAULT NULL,
`loginpwd` int(10) NOT NULL,
`telphone` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `t_login_logid` (
 login_log_id  INT AUTO_INCREMENT PRIMARY KEY,
   user_id   INT,
   ip  VARCHAR(23),
   login_datetime datetime
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
INSERT INTO user (username,usersex,loginpwd,telphone) VALUES('admin','man','123456','17328040829');



commit;